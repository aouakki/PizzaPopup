<?php
/**
 * Created by PhpStorm.
 * User: abdo
 * Date: 29/06/17
 * Time: 01:27 م
 */

//------------------- Edit here --------------------//
$sendy_url = 'http://mypizzashop.website/emkt/';
$list = 'wU763ulstdOrS1jEfXPDsjyw';
//------------------ /Edit here --------------------//

//--------------------------------------------------//
//POST variables
$email = $_POST['email'];

//subscribe
$postdata = http_build_query(
    array(
        'email' => $email,
        'list' => $list,
        'boolean' => 'true'
    )
);
$opts = array('http' => array('method'  => 'POST', 'header'  => 'Content-type: application/x-www-form-urlencoded', 'content' => $postdata));
$context  = stream_context_create($opts);
$result = file_get_contents($sendy_url.'/subscribe.php', false, $context);
//--------------------------------------------------//

echo $result;